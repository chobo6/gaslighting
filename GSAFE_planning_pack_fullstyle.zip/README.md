# G-SAFE 기획 발표 산출물 패키지

프로젝트명: G-SAFE  
부제: Unity 기반 가스 누출 위험률 예측 및 자동차단 시뮬레이션  
기간: 2026.06.16 – 2026.07.13  
발표일: 2026.07.13

## 핵심 실행 파일

- `final_presentation.html`: 전체 기획 발표자료. 하위 문서를 iframe으로 포함.
- `requirements.html`: 요구사항 명세서
- `wbs.html`: WBS 및 일정 요약
- `menu_scenario.html`: 메뉴트리 및 사용자 시나리오
- `wireframe.html`: 화면 와이어프레임
- `storyboard.html`: 스토리보드
- `table_definition.html`: 테이블 정의서 및 ERD
- `test_cases.html`: 테스트 케이스
- `troubleshooting.html`: 트러블슈팅 및 회고

## 폴더

- `md/`: 제출용 Markdown 문서
- `csv/`: 붙여넣기용 CSV
- `images/`: 발표자료 와이어프레임 이미지
