# API · DB 설계

## API
- POST /api/predict-risk
- POST /api/cutoff-events
- GET /api/scenarios
- GET /api/model-metrics

## ERD
```text
gas_scenarios 1 ─── N gas_readings
gas_scenarios 1 ─── N risk_predictions
gas_scenarios 1 ─── N cutoff_events
model_metrics 독립 테이블
```
