# Unity 시뮬레이션 설계

## 오브젝트
- Lab Room
- Gas Pipe
- Leak Point
- Gas Particle
- Auto Valve
- Alarm Light
- Ventilation Fan
- Risk HUD
